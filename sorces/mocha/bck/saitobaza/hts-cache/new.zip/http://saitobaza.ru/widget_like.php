<!DOCTYPE html>
<!DOCTYPE html>
<!--[if lt IE 7]><html lang="ru-RU" prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb#" class="no-js lt-ie9 lt-ie8 lt-ie7"><![endif]-->
<!--[if IE 7]><html lang="ru-RU" prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb#" class="no-js lt-ie9 lt-ie8"><![endif]-->
<!--[if IE 8]><html lang="ru-RU" prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb#" class="no-js lt-ie9"><![endif]-->
<!--[if gt IE 8]><!--><html lang="ru-RU" prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb#" class="no-js"><!--<![endif]--> 
<head>
	<meta charset="UTF-8">
	
		
		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->

		<meta name="viewport" content="width=device-width, initial-scale=1"/>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta name='loginza-verification' content='f0ef6ba77cc56d571fe973fc1bc16c52' />
		<!-- Adding "maximum-scale=1" fixes the Mobile Safari auto-zoom bug: http://filamentgroup.com/examples/iosScaleBug/ -->
		
		<link rel="stylesheet" media="all" href="http://saitobaza.ru/wp-content/themes/wp-saitobaza/style.css"/>
		
		
<!-- This site is optimized with the Yoast WordPress SEO plugin v1.4.19 - http://yoast.com/wordpress/seo/ -->
<title>Страница не найдена - Сайтобаза</title>
<meta name="robots" content="noodp,noydir"/>
<link rel="publisher" href="https://plus.google.com/118152068545448105558"/>
<meta property="og:locale" content="ru_RU" />
<meta property="og:type" content="website" />
<meta property="og:title" content="Страница не найдена - Сайтобаза" />
<meta property="og:site_name" content="Сайтобаза" />
<meta property="og:image" content="http://saitobaza.ru/wp-content/uploads/2012/12/turbo121220122149460001.png" />
<!-- / Yoast WordPress SEO plugin. -->

<link rel='stylesheet' id='contact-form-7-css'  href='http://saitobaza.ru/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=3.5.4' media='all' />
<link rel='stylesheet' id='pay-with-a-like-css'  href='http://saitobaza.ru/wp-content/plugins/pay-with-a-like/css/front.css?ver=1.1.0' media='all' />
<link rel='stylesheet' id='quotescollection-style-css'  href='http://saitobaza.ru/wp-content/plugins/quotes-collection/quotes-collection.css?ver=1.5.7' media='all' />
<link rel='stylesheet' id='responsive-lightbox-prettyphoto-front-css'  href='http://saitobaza.ru/wp-content/plugins/responsive-lightbox/assets/prettyphoto/css/prettyPhoto.css?ver=3.7.1' media='all' />
<link rel='stylesheet' id='html5blank-css'  href='http://saitobaza.ru/wp-content/themes/wp-saitobaza/style.css?ver=1.0' media='all' />
<link rel='stylesheet' id='wp-ui-css'  href='http://saitobaza.ru/wp-content/plugins/wp-ui/css/wp-ui.css?ver=3.7.1' media='all' />
<link rel='stylesheet' id='wpui-light-css'  href='http://saitobaza.ru/wp-content/plugins/wp-ui/css/themes/wpui-light.css?ver=3.7.1' media='all' />
<link rel='stylesheet' id='wp-ui-all-css'  href='http://saitobaza.ru/wp-content/plugins/wp-ui/css/themes/wpui-all.css?ver=3.7.1' media='all' />
<meta property='vk:app_id' content='3292431' />
<meta property='vkapi:wpurl' content='http://saitobaza.ru' />
<meta property="fb:admins" content="crazyyy"/>
<script type='text/javascript' src='http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js?ver=1.8.2'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var QCAjax = {"ajaxurl":"http:\/\/saitobaza.ru\/wp-admin\/admin-ajax.php","nonce":"f20892fdcf","nextquote":"\u0421\u043b\u0435\u0434\u0443\u044e\u0449\u0430\u044f \u0446\u0438\u0442\u0430\u0442\u0430\u00a0\u00bb","loading":"\u0441\u0435\u043a\u0443\u043d\u0434\u043e\u0447\u043a\u0443...","error":"\u041e\u0448\u0438\u0431\u043a\u0430 \u0441\u043e\u0437\u0434\u0430\u043d\u0438\u044f \u0446\u0438\u0442\u0430\u0442\u044b","auto_refresh_max":"30","auto_refresh_count":"0"};
/* ]]> */
</script>
<script type='text/javascript' src='http://saitobaza.ru/wp-content/plugins/quotes-collection/quotes-collection.js?ver=1.5.7'></script>
<script type='text/javascript' src='http://saitobaza.ru/wp-content/themes/wp-saitobaza/js/modernizr.js?ver=2.6.2'></script>
<script type='text/javascript' src='http://saitobaza.ru/wp-content/plugins/vkontakte-api/js/callback.js?ver=3.7.1'></script>
<script type='text/javascript' src='http://saitobaza.ru/wp-content/plugins/responsive-lightbox/assets/prettyphoto/js/jquery.prettyPhoto.js?ver=3.7.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var rlArgs = {"script":"prettyphoto","selector":"lightbox","activeGalleries":"1","animationSpeed":"normal","slideshow":"0","slideshowDelay":"5000","slideshowAutoplay":"0","opacity":"0.75","showTitle":"1","allowResize":"1","width":"1080","height":"720","separator":"\/","theme":"pp_default","horizontalPadding":"20","hideFlash":"0","wmode":"opaque","videoAutoplay":"0","modal":"0","deeplinking":"1","overlayGallery":"1","keyboardShortcuts":"1","social":"0"};
/* ]]> */
</script>
<script type='text/javascript' src='http://saitobaza.ru/wp-content/plugins/responsive-lightbox/js/front.js?ver=3.7.1'></script>
<script type='text/javascript' src='http://saitobaza.ru/wp-includes/js/jquery/ui/jquery.ui.core.min.js?ver=1.10.3'></script>
<script type='text/javascript' src='http://saitobaza.ru/wp-includes/js/jquery/ui/jquery.ui.widget.min.js?ver=1.10.3'></script>
<script type='text/javascript' src='http://saitobaza.ru/wp-includes/js/jquery/ui/jquery.ui.tabs.min.js?ver=1.10.3'></script>
<script type='text/javascript' src='http://saitobaza.ru/wp-includes/js/jquery/ui/jquery.ui.accordion.min.js?ver=1.10.3'></script>
<script type='text/javascript' src='http://saitobaza.ru/wp-includes/js/jquery/ui/jquery.ui.mouse.min.js?ver=1.10.3'></script>
<script type='text/javascript' src='http://saitobaza.ru/wp-includes/js/jquery/ui/jquery.ui.resizable.min.js?ver=1.10.3'></script>
<script type='text/javascript' src='http://saitobaza.ru/wp-includes/js/jquery/ui/jquery.ui.draggable.min.js?ver=1.10.3'></script>
<script type='text/javascript' src='http://saitobaza.ru/wp-includes/js/jquery/ui/jquery.ui.button.min.js?ver=1.10.3'></script>
<script type='text/javascript' src='http://saitobaza.ru/wp-includes/js/jquery/ui/jquery.ui.position.min.js?ver=1.10.3'></script>
<script type='text/javascript' src='http://saitobaza.ru/wp-includes/js/jquery/ui/jquery.ui.dialog.min.js?ver=1.10.3'></script>
<script type='text/javascript' src='http://saitobaza.ru/wp-includes/js/jquery/ui/jquery.ui.sortable.min.js?ver=1.10.3'></script>
<script type='text/javascript' src='http://saitobaza.ru/?wpui-script=before&#038;ver=3.7.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wpUIOpts = {"wpUrl":"http:\/\/saitobaza.ru","pluginUrl":"http:\/\/saitobaza.ru\/wp-content\/plugins\/wp-ui\/","enableTabs":"on","enableAccordion":"on","enableSpoilers":"on","enableDialogs":"on","tabsEffect":"none","effectSpeed":"","accordEffect":"none","alwaysRotate":"disable","tabsEvent":"click","collapsibleTabs":"off","accordEvent":"click","singleLineTabs":"","accordAutoHeight":"off","accordCollapsible":"off","accordEasing":"false","mouseWheelTabs":"false","bottomNav":"off","tabPrevText":"","tabNextText":"","spoilerShowText":"","spoilerHideText":"","cookies":"off","hashChange":"off","docWriteFix":"off","linking_history":"off","misc_options":""};
/* ]]> */
</script>
<script type='text/javascript' src='http://saitobaza.ru/wp-content/plugins/wp-ui/js/wp-ui.js?ver=0.8.8'></script>
<link rel="stylesheet" type="text/css" href="http://saitobaza.ru/wp-content/plugins/wp-code-highlight/css/desert.css" media="screen" />
		
		<!-- CSS + jQuery + JavaScript -->
		<script src="http://saitobaza.ru/wp-content/themes/wp-saitobaza/js/css3-mediaqueries.js"></script>
		<script src="http://saitobaza.ru/wp-content/themes/wp-saitobaza/js/custom.js"></script>
		<script src="http://saitobaza.ru/wp-content/themes/wp-saitobaza/js/tabs.js"></script>
		
		<!-- superfish -->
		<link rel="stylesheet" media="screen" href="http://saitobaza.ru/wp-content/themes/wp-saitobaza/css/superfish.css" /> 
		<script  src="http://saitobaza.ru/wp-content/themes/wp-saitobaza/js/superfish-1.4.8/js/hoverIntent.js"></script>
		<script  src="http://saitobaza.ru/wp-content/themes/wp-saitobaza/js/superfish-1.4.8/js/superfish.js"></script>
		<script  src="http://saitobaza.ru/wp-content/themes/wp-saitobaza/js/superfish-1.4.8/js/supersubs.js"></script>
		<!-- ENDS superfish -->
		
		<!-- poshytip -->
		<link rel="stylesheet" href="http://saitobaza.ru/wp-content/themes/wp-saitobaza/js/poshytip-1.1/src/tip-twitter/tip-twitter.css"  />
		<link rel="stylesheet" href="http://saitobaza.ru/wp-content/themes/wp-saitobaza/js/poshytip-1.1/src/tip-yellowsimple/tip-yellowsimple.css"  />
		<script  src="http://saitobaza.ru/wp-content/themes/wp-saitobaza/js/poshytip-1.1/src/jquery.poshytip.min.js"></script>
		<!-- ENDS poshytip -->

		<!-- Flex Slider -->
		<link rel="stylesheet" href="http://saitobaza.ru/wp-content/themes/wp-saitobaza/css/flexslider.css" >
		<script src="http://saitobaza.ru/wp-content/themes/wp-saitobaza/js/jquery.flexslider-min.js"></script>
		<!-- ENDS Flex Slider -->
		
		<!-- Masonry -->
		<script src="http://saitobaza.ru/wp-content/themes/wp-saitobaza/js/masonry.min.js" ></script>
		<script src="http://saitobaza.ru/wp-content/themes/wp-saitobaza/js/imagesloaded.js" ></script>
		<!-- ENDS Masonry -->
		
		<!-- Less framework -->
		<link rel="stylesheet" media="all" href="http://saitobaza.ru/wp-content/themes/wp-saitobaza/css/lessframework.css"/>
		
		<!-- SKIN -->
		<link rel="shortcut icon" href="http://saitobaza.ru/wp-content/themes/wp-saitobaza/favicon.ico">
	</head>
	
	<body>
	
		<header>
			<div class="wrapper clearfix">
				<div id="logo">
					<a href="http://saitobaza.ru/" title="Сайтобаза" rel="home"><img src="http://saitobaza.ru/wp-content/themes/wp-saitobaza/img/saitobaza-logo.png" alt="Страница не найдена - Сайтобаза : Сайтобаза"></a>
				</div>
				<!-- Nav -->
				<nav>
				<ul id="nav" class="sf-menu"><li id="menu-item-1668" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-1668"><a href="http://saitobaza.ru">Главная</a></li>
<li id="menu-item-1835" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-1835"><a href="http://saitobaza.ru/category/blog">Блог</a></li>
<li id="menu-item-1670" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-1670"><a href="http://saitobaza.ru/category/portfolio">Портфолио</a></li>
<li id="menu-item-1672" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-1672"><a href="http://saitobaza.ru/soft-skripty.htm">Софт / Скрипты</a>
<ul class="sub-menu">
	<li id="menu-item-1673" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1673"><a href="http://saitobaza.ru/soft-skripty/content-downloader-nedorogoj-universalnyj-parser-kontenta.htm">Content Downloade</a></li>
	<li id="menu-item-1674" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1674"><a href="http://saitobaza.ru/soft-skripty/key-collector-avtomaticheskoe-sostavlenie-semanticheskogo-yadra.htm">Key Collector</a></li>
	<li id="menu-item-1675" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1675"><a href="http://saitobaza.ru/soft-skripty/wordpress.htm">WordPress</a></li>
	<li id="menu-item-1676" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1676"><a href="http://saitobaza.ru/soft-skripty/zebroid.htm">Зеброид</a></li>
</ul>
</li>
<li id="menu-item-1677" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-1677"><a href="http://saitobaza.ru/uslugi.htm">Услуги</a>
<ul class="sub-menu">
	<li id="menu-item-1679" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1679"><a href="http://saitobaza.ru/uslugi/avtomatizaciya.htm">Автоматизация</a></li>
	<li id="menu-item-1678" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1678"><a href="http://saitobaza.ru/uslugi/obuchenie.htm">Обучение</a></li>
	<li id="menu-item-1680" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1680"><a href="http://saitobaza.ru/uslugi/parsing.htm">Парсинг и копипаст контента.</a></li>
	<li id="menu-item-1681" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1681"><a href="http://saitobaza.ru/uslugi/verstka.htm">Верстка сайтов</a></li>
	<li id="menu-item-1682" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1682"><a href="http://saitobaza.ru/uslugi/verstka/forma-zayavki-na-verstku-sajta-i-natyazhku-na-cms.htm">Заявки на верстку</a></li>
</ul>
</li>
<li id="menu-item-1683" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-1683"><a href="http://saitobaza.ru/kontakty.htm">Мои контактные данные</a>
<ul class="sub-menu">
	<li id="menu-item-1684" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1684"><a href="http://saitobaza.ru/kontakty/obo-mne.htm">Обо мне</a></li>
</ul>
</li>
</ul>				</nav>
				<!-- /Nav -->
			

				<select id="comboNav"><option class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-1668"><a href="http://saitobaza.ru">Главная</a></option>
<option class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-1835"><a href="http://saitobaza.ru/category/blog">Блог</a></option>
<option class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-1670"><a href="http://saitobaza.ru/category/portfolio">Портфолио</a></option>
<option class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-1672"><a href="http://saitobaza.ru/soft-skripty.htm">Софт / Скрипты</a>	<option class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1673"><a href="http://saitobaza.ru/soft-skripty/content-downloader-nedorogoj-universalnyj-parser-kontenta.htm">&nbsp;&nbsp;&nbsp;&nbsp;Content Downloade</a></option>
	<option class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1674"><a href="http://saitobaza.ru/soft-skripty/key-collector-avtomaticheskoe-sostavlenie-semanticheskogo-yadra.htm">&nbsp;&nbsp;&nbsp;&nbsp;Key Collector</a></option>
	<option class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1675"><a href="http://saitobaza.ru/soft-skripty/wordpress.htm">&nbsp;&nbsp;&nbsp;&nbsp;WordPress</a></option>
	<option class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1676"><a href="http://saitobaza.ru/soft-skripty/zebroid.htm">&nbsp;&nbsp;&nbsp;&nbsp;Зеброид</a></option>
</option>
<option class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-1677"><a href="http://saitobaza.ru/uslugi.htm">Услуги</a>	<option class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1679"><a href="http://saitobaza.ru/uslugi/avtomatizaciya.htm">&nbsp;&nbsp;&nbsp;&nbsp;Автоматизация</a></option>
	<option class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1678"><a href="http://saitobaza.ru/uslugi/obuchenie.htm">&nbsp;&nbsp;&nbsp;&nbsp;Обучение</a></option>
	<option class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1680"><a href="http://saitobaza.ru/uslugi/parsing.htm">&nbsp;&nbsp;&nbsp;&nbsp;Парсинг и копипаст контента.</a></option>
	<option class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1681"><a href="http://saitobaza.ru/uslugi/verstka.htm">&nbsp;&nbsp;&nbsp;&nbsp;Верстка сайтов</a></option>
	<option class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1682"><a href="http://saitobaza.ru/uslugi/verstka/forma-zayavki-na-verstku-sajta-i-natyazhku-na-cms.htm">&nbsp;&nbsp;&nbsp;&nbsp;Заявки на верстку</a></option>
</option>
<option class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-1683"><a href="http://saitobaza.ru/kontakty.htm">Мои контактные данные</a>	<option class="menu-item menu-item-type-post_type menu-item-object-page menu-item-1684"><a href="http://saitobaza.ru/kontakty/obo-mne.htm">&nbsp;&nbsp;&nbsp;&nbsp;Обо мне</a></option>
</option>
</select>
				
			
			<!-- slider holder -->
			<div class="clearfix"></div>
							
			<!-- slider holder -->
				
			</div>
		</header>
<!-- MAIN -->
<div id="main">
  <div class="wrapper clearfix"> 
    
    <!-- masthead -->
    <div class="masthead clearfix">
      <h1>
        Страница не найдена      </h1>
    </div>
    <div class='mh-div'></div>
    <!-- ENDS masthead --> 
    
    <!-- Section -->
    <section> 
      
      <!-- page content -->
      <div id="page-content" class="clearfix">
        <h2><a href="http://saitobaza.ru">
          Вернутся назад?          </a></h2>
      </div>
      <!-- ENDS page content --> 
      
    </section>
    <!-- /Section --> 
    
    <!-- Fold image -->
    <div id="fold"></div>
  </div>
</div>
<!-- ENDS MAIN -->
	<!--WP Code Highlight_start-->
	<script type="text/javascript">
		window.onload = function(){prettyPrint();};
	</script>
	<script type="text/javascript" src="http://saitobaza.ru/wp-content/plugins/wp-code-highlight/js/wp-code-highlight.js"></script>
	<!--WP Code Highlight_end-->
		
		<footer>	
			
			<div class="wrapper clearfix">
				
				<!-- widgets -->
				<ul  class="widget-cols clearfix">
					<li class="first-col">
						<!-- Sidebar -->
<aside id="footsidebar">


	 
						<div class="widget-block">
							<h4>ПОСЛЕДНИЕ РАБОТЫ</h4>
							
				
			
						<div class="recent-post clearfix">
								<a class="widget54" href="http://saitobaza.ru/wp-content/uploads/2013/12/zzzebraPDF-23-1-700x393.jpg" title="Праздничные скидки на Зеброид" ><img src="http://saitobaza.ru/wp-content/uploads/2013/12/zzzebraPDF-23-1-120x67.jpg" class="attachment-54x54 wp-post-image" alt="Скидки на Зеброид" /></a>								<div class="post-head">
									<a href="http://saitobaza.ru/prazdnichnye-skidki-na-zebroid.htm" rel="nofollow" title="Праздничные скидки на Зеброид" class="poshytip">Праздничные скидки на Зеброид</a><span>9 Декабрь, 2013</span>
								</div>
							</div>
			
			
				
			
						<div class="recent-post clearfix">
								<a class="widget54" href="http://saitobaza.ru/wp-content/uploads/2013/12/css3ps2-700x525.jpg" title="Скопировать стиль фотошопа" ><img src="http://saitobaza.ru/wp-content/uploads/2013/12/css3ps2-120x90.jpg" class="attachment-54x54 wp-post-image" alt="css3ps2" /></a>								<div class="post-head">
									<a href="http://saitobaza.ru/skopirovat-stil-fotoshopa.htm" rel="nofollow" title="Скопировать стиль фотошопа" class="poshytip">Скопировать стиль фотошопа</a><span>8 Декабрь, 2013</span>
								</div>
							</div>
			
			
				
			
						<div class="recent-post clearfix">
								<a class="widget54" href="http://saitobaza.ru/wp-content/uploads/2013/12/psd-to-html1.png" title="Как подготовить PSD макет для правильной верстки" ><img src="http://saitobaza.ru/wp-content/uploads/2013/12/psd-to-html1-120x55.png" class="attachment-54x54 wp-post-image" alt="psd-to-html[1]" /></a>								<div class="post-head">
									<a href="http://saitobaza.ru/kak-podgotovit-psd-maket-dlya-pravilnoj-verstki.htm" rel="nofollow" title="Как подготовить PSD макет для правильной верстки" class="poshytip">Как подготовить PSD макет для правильной верстки</a><span>8 Декабрь, 2013</span>
								</div>
							</div>
			
			
										
						</div>
 
			
</aside>
<!-- /Sidebar -->					</li>
					
					<li class="second-col">
						<!-- Sidebar -->
<aside id="footsidebar">


	 
		<div class="widget-block widget_nav_menu" id="nav_menu-3""><h4>Важные страницы</h4><div class="menu-podvalnye-stranicy-container"><ul id="menu-podvalnye-stranicy" class="menu"><li id="menu-item-1965" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-1965"><a href="http://saitobaza.ru/skidka-na-zebroid.htm">Скидка на Зеброид</a></li>
</ul></div></div> 
			
</aside>
<!-- /Sidebar -->					</li>
					
					<li class="third-col">
						<!-- Sidebar -->
<aside id="footsidebar">


	 
		<div class="widget-block widget_text" id="text-3""><h4>Последние из копипасты</h4>			<div class="textwidget"> </div>
		</div> 
			
</aside>
<!-- /Sidebar -->					</li>
					
					<li class="fourth-col">
						<!-- Sidebar -->
<aside id="footsidebar">


	 
		<div class="widget-block widget_hlinks" id="hlinks-2""><h4>Ещё немного</h4>30<ul style="margin-top:0"><li><a href="http://saitobaza.ru/" title="Обучение созданию скриптов с нуля">Изменить дизайн woocommerce</a></li> <li><a href="http://saitobaza.ru/category/portfolio" title="Портфолио верстальщика">Дизайнер верстальщик портфолио</a></li> <li><a href="http://saitobaza.ru/uslugi/verstka.htm" title="Натяжка на Wordpress">Верстка сайта цена</a></li> <li><a href="http://saitobaza.ru/verstka-htmlcssjs-buxmejster.htm" title="Css ромбики">Css ромбики</a></li> <li><a href="http://saitobaza.ru/css3ps-plagin-dlya-kopirovaniya-stilej-sloev-photoshopa.htm" title="Скопировать стиль из фотошопа на сайт">Скопировать стиль из фотошопа на сайт</a></li> <li><a href="http://saitobaza.ru/soft-skripty/content-downloader-nedorogoj-universalnyj-parser-kontenta.htm" title="Контентдаунлоадером">Контентдаунлоадером</a></li> <li><a href="http://saitobaza.ru/metody-generacii-pravilnoj-karty-sajta-sitemap.htm" title="Генерирование моя страница">Генерирование моя страница</a></li> <li><a href="http://saitobaza.ru/kak-perevesti-temu-ili-plagin-wordpress-poshagovaya-instrukciya.htm" title="Перевод Плагинов вордпресс">Перевод Плагинов вордпресс</a></li> <li><a href="http://saitobaza.ru/podklyuchenie-plagina-woocommerce-v-nestandartnuyu-temu.htm" title="Woocommerce">Woocommerce</a></li> <li><a href="http://saitobaza.ru/soft-skripty/key-collector-avtomaticheskoe-sostavlenie-semanticheskogo-yadra.htm" title="Key collector ядро">Key collector ядро</a></li></ul></div> 
	
</aside>
<!-- /Sidebar -->	
					</li>	
				</ul>
				<!-- ENDS widgets -->	
				
				
				<!-- bottom -->
				<div class="footer-bottom">
					<div class="left">Шаблон создан мной специально для <a href="http://saitobaza.ru" >Сайтобазы</a></div>
					<div class="right">
						<ul id="social-bar">
							<li><a rel="nofollow" href="http://www.facebook.com/crazyyy"  title="Друзяшка в FB" class="poshytip"><img src="http://saitobaza.ru/wp-content/themes/wp-saitobaza/img/social/facebook.png"  alt="Facebook" /></a></li>
							<li><a rel="nofollow" href="https://twitter.com/saitobaza" title="Следить в твиттере" class="poshytip"><img src="http://saitobaza.ru/wp-content/themes/wp-saitobaza/img/social/twitter.png"  alt="twitter" /></a></li>
							<li><a rel="nofollow"  href="https://plus.google.com/114045745754235362317"  title="Добавить в круг Google+" class="poshytip"><img src="http://saitobaza.ru/wp-content/themes/wp-saitobaza/img/social/plus.png" alt="Google plus" /></a></li>
							<li><div class="counter"><!--LiveInternet counter--><script type="text/javascript">document.write("<a href='http://www.liveinternet.ru/click' target=_blank><img src='//counter.yadro.ru/hit?t50.12;r" + escape(document.referrer) + ((typeof(screen)=="undefined")?"":";s"+screen.width+"*"+screen.height+"*"+(screen.colorDepth?screen.colorDepth:screen.pixelDepth)) + ";u" + escape(document.URL) + ";" + Math.random() + "' border=0 width=31 height=31 alt='' title='LiveInternet'><\/a>")</script><!--/LiveInternet--></div></li>
						</ul>
					</div>
				</div>	
				<!-- ENDS bottom -->		

			</div>
		</footer>
		<!-- Yandex.Metrika counter -->
<script type="text/javascript">
(function (d, w, c) {
    (w[c] = w[c] || []).push(function() {
        try {
            w.yaCounter11719195 = new Ya.Metrika({id:11719195,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true,
                    trackHash:true});
        } catch(e) { }
    });
    var n = d.getElementsByTagName("script")[0],
        s = d.createElement("script"),
        f = function () { n.parentNode.insertBefore(s, n); };
    s.type = "text/javascript";
    s.async = true;
    s.src = (d.location.protocol == "https:" ? "https:" : "http:") + "//mc.yandex.ru/metrika/watch.js";

    if (w.opera == "[object Opera]") {
        d.addEventListener("DOMContentLoaded", f, false);
    } else { f(); }
})(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="//mc.yandex.ru/watch/11719195" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter    -->
		<div id="vkapi_body">        <div id="vk_api_transport"></div>
        <script type="text/javascript">
            window.vkAsyncInit = function () {
                VK.init({
                    apiId: 3292431
                });
                VK.Observer.subscribe('widgets.comments.new_comment', onChangePlusVK);
                VK.Observer.subscribe('widgets.comments.delete_comment', onChangeMinusVK);
                jQuery("body").trigger('vkapi_vk');
            };

            setTimeout(function () {
                var el = document.createElement("script");
                el.type = "text/javascript";
                el.src = "https://vk.com/js/api/openapi.js";
                el.async = true;
                document.getElementById("vk_api_transport").appendChild(el);
            }, 0);
        </script>
            <div id="vk_share_transport"></div>
    <script type="text/javascript">
        setTimeout(function () {
            var el = document.createElement("script");
            el.type = "text/javascript";
            el.src = "https://vk.com/js/api/share.js";
            el.async = true;
            document.getElementById("vk_share_transport").appendChild(el);
        }, 0);
    </script>
        <div id="gp_plusone_transport"></div>
    <script type="text/javascript">
        setTimeout(function () {
            var el = document.createElement("script");
            el.type = "text/javascript";
            el.src = "https://apis.google.com/js/plusone.js";
            el.async = true;
            document.getElementById("gp_plusone_transport").appendChild(el);
        }, 0);
    </script>
            <div id="fb-root"></div>
        <script>
            window.fbAsyncInit = function () {
                FB.init({
                    appId: 445848335480713,
                    status:true,
                    cookie:true,
                    xfbml:true
                });
                FB.Event.subscribe('comment.create', onChangePlusFB);
                FB.Event.subscribe('comment.remove', onChangeMinusFB);
                jQuery("body").trigger('vkapi_fb');
            };

            (function (d) {
                var js, id = 'facebook-jssdk', ref = d.getElementsByTagName('script')[0];
                if (d.getElementById(id)) {
                    return;
                }
                js = d.createElement('script');
                js.id = id;
                js.async = true;
                js.src = "//connect.facebook.net/ru_RU/all.js";
                ref.parentNode.insertBefore(js, ref);
            }(document));
        </script>
            <script type="text/javascript"> !function (d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (!d.getElementById(id)) {
            js = d.createElement(s);
            js.id = id;
            js.src = "//platform.twitter.com/widgets.js";
            fjs.parentNode.insertBefore(js, fjs);
        }
    }(document, "script", "twitter-wjs");</script>
    </div><style>
	a.loginza:hover, a.loginza {text-decoration:none;}
	a.loginza img {border:0px;margin-right:3px;}
</style>

<script type="text/javascript">
function loginza_load_jquery () {
  if (typeof jQuery != 'undefined') {
    if (typeof $ == 'undefined') {
      $ = jQuery;
    }
    return true;
  }
  if (typeof loginza_jquery_written == 'undefined'){
    document.write("<scr" + "ipt type=\"text/javascript\" src=\"http://saitobaza.ru/wp-content/plugins/loginza/js/jquery-1.6.2.min.js\"></scr" + "ipt>");
    loginza_jquery_written = true;
  }
  setTimeout('loginza_load_jquery()', 60);
  return false;
}
loginza_load_jquery();
</script>

<script src="//loginza.ru/js/widget-2.0.js" type="text/javascript"></script>
<script type="text/javascript">
	$(document).ready(function(){
    	$('#commentform').prepend('<p id="loginza_comment">Вы можете войти через социальные сети <br/><a href="https://loginza.ru/api/widget?token_url=http%3A%2F%2Fsaitobaza.ru%2Fwidget_like.php&providers_set=google,twitter,webmoney,openid,mailru,livejournal,odnoklassniki,linkedin&lang=ru&theme=grey" class="loginza"><img src="http://saitobaza.ru/wp-content/plugins/loginza/img/sign_in_button_gray.gif" alt="Вход через социальные сети" title="Вход через социальные сети" align="middle"/></p>');
    });

	var widget_id = '39975';

    // инициализация
    LOGINZA.Widget.init(widget_id);
</script>
<script type='text/javascript'></script><!-- Optimised Asynchronous Google Analytics --><script>var _gaq=[['_setAccount','UA-28155960-1'],['_trackPageview']];
            (function(d,t){var g=d.createElement(t),s=d.getElementsByTagName(t)[0];
            g.src=('https:'==location.protocol?'//ssl':'//www')+'.google-analytics.com/ga.js';
            s.parentNode.insertBefore(g,s)}(document,'script'));</script><!-- Protocol Relative jQuery fall back if Google CDN offline --><script>window.jQuery || document.write('<script src="http://saitobaza.ru/wp-content/themes/wp-saitobaza/js/jquery-1.8.2.min.js"><\/script>')</script><script type='text/javascript' src='http://saitobaza.ru/wp-content/plugins/contact-form-7/includes/js/jquery.form.min.js?ver=3.45.0-2013.10.17'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpcf7 = {"loaderUrl":"http:\/\/saitobaza.ru\/wp-content\/plugins\/contact-form-7\/images\/ajax-loader.gif","sending":"\u041e\u0442\u043f\u0440\u0430\u0432\u043a\u0430...","cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='http://saitobaza.ru/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=3.5.4'></script>
	
	</body>

</html>