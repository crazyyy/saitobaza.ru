Hello,

Thank you for buying New RoyalSlider for WordPress

Install plugin via WordPress admin as usually with file new-royalslider.zip 
(Plugins > Add New > Upload)


Documentation, tutorials and tips can be found on support desk.
http://dimsemenov.com/plugins/royal-slider/support/


—
Dmitry Semenov
http://dimsemenov.com
