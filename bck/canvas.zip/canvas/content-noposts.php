<div class="post">
	<p><?php echo apply_filters( 'woo_noposts_message', __( 'Sorry, no posts matched your criteria.', 'woothemes' ) ); ?></p>
</div><!-- /.post -->