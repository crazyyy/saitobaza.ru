<!DOCTYPE html>
<!--[if lt IE 7]><html <?php language_attributes(); ?> class="no-js lt-ie9 lt-ie8 lt-ie7"><![endif]-->
<!--[if IE 7]><html <?php language_attributes(); ?> class="no-js lt-ie9 lt-ie8"><![endif]-->
<!--[if IE 8]><html <?php language_attributes(); ?> class="no-js lt-ie9"><![endif]-->
<!--[if gt IE 8]><!--><html <?php language_attributes(); ?> class="no-js"><!--<![endif]--> 
<head>
	<meta charset="UTF-8">
	<title><?php wp_title(''); ?><?php if(wp_title('', false)) { echo ' :'; } ?> <?php bloginfo('name'); ?></title>
		
		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		
		
		<link rel="stylesheet" media="all" href="<?php echo get_template_directory_uri(); ?>/css/style.css"/>
		<meta name="viewport" content="width=device-width, initial-scale=1"/>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<!-- Adding "maximum-scale=1" fixes the Mobile Safari auto-zoom bug: http://filamentgroup.com/examples/iosScaleBug/ -->
		
		<?php wp_head(); ?>
		
		<!-- CSS + jQuery + JavaScript -->
		<script src="<?php echo get_template_directory_uri(); ?>/js/css3-mediaqueries.js"></script>
		<script src="<?php echo get_template_directory_uri(); ?>/js/custom.js"></script>
		<script src="<?php echo get_template_directory_uri(); ?>/js/tabs.js"></script>
		
		<!-- Tweet -->
		<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/jquery.tweet.css" media="all"  /> 
		<script src="<?php echo get_template_directory_uri(); ?>/js/tweet/jquery.tweet.js" ></script> 
		<!-- ENDS Tweet -->
		
		<!-- superfish -->
		<link rel="stylesheet" media="screen" href="<?php echo get_template_directory_uri(); ?>/css/superfish.css" /> 
		<script  src="<?php echo get_template_directory_uri(); ?>/js/superfish-1.4.8/js/hoverIntent.js"></script>
		<script  src="<?php echo get_template_directory_uri(); ?>/js/superfish-1.4.8/js/superfish.js"></script>
		<script  src="<?php echo get_template_directory_uri(); ?>/js/superfish-1.4.8/js/supersubs.js"></script>
		<!-- ENDS superfish -->
		
		<!-- prettyPhoto -->
		<script  src="<?php echo get_template_directory_uri(); ?>/js/prettyPhoto/js/jquery.prettyPhoto.js"></script>
		<link rel="stylesheet" href="js/prettyPhoto/css/prettyPhoto.css"  media="screen" />
		<!-- ENDS prettyPhoto -->
		
		<!-- poshytip -->
		<link rel="stylesheet" href="js/poshytip-1.1/src/tip-twitter/tip-twitter.css"  />
		<link rel="stylesheet" href="js/poshytip-1.1/src/tip-yellowsimple/tip-yellowsimple.css"  />
		<script  src="<?php echo get_template_directory_uri(); ?>/js/poshytip-1.1/src/jquery.poshytip.min.js"></script>
		<!-- ENDS poshytip -->
		
		<!-- GOOGLE FONTS -->
		<link href='http://fonts.googleapis.com/css?family=Arvo:400,700' rel='stylesheet' type='text/css'>
		
		<!-- Flex Slider -->
		<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/flexslider.css" >
		<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.flexslider-min.js"></script>
		<!-- ENDS Flex Slider -->
		
		<!-- Masonry -->
		<script src="<?php echo get_template_directory_uri(); ?>/js/masonry.min.js" ></script>
		<script src="<?php echo get_template_directory_uri(); ?>/js/imagesloaded.js" ></script>
		<!-- ENDS Masonry -->
		
		<!-- Less framework -->
		<link rel="stylesheet" media="all" href="<?php echo get_template_directory_uri(); ?>/css/lessframework.css"/>
		
		<!-- SKIN -->
		<link rel="stylesheet" media="all" href="<?php echo get_template_directory_uri(); ?>/css/skin.css"/>		
		<link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/favicon.ico">
		
		

	</head>
	
	<body>
	
		<header>
			<div class="wrapper clearfix">
				
				<div id="logo">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><img src="<?php echo get_template_directory_uri(); ?>/img/saitobaza-logo.png" alt="<?php wp_title(''); ?><?php if(wp_title('', false)) { echo ' :'; } ?> <?php bloginfo('name'); ?>"></a>
				</div>
				
				
				<!-- Nav -->
				<nav>
				<?php $args = array(
				  'theme_location'  => 'top',
				  'menu'            => 'top', 
				  'container'       => 'ul', 
				  'container_class' => 'sf-menu', 
				  'container_id'    => 'nav',
				  'menu_class'      => 'sf-menu', 
				  'menu_id'         => 'nav',
				  'echo'            => true,
				  'fallback_cb'     => 'wp_page_menu',
				  'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>',
				  'depth'           => 0	  ); 
				  wp_nav_menu( $args ); ?>
				</nav>
				<!-- /Nav -->
			

				<?php class Walker_Nav_Menu_Dropdown extends Walker_Nav_Menu{
				function start_lvl(&$output, $depth){
				  $indent = str_repeat("\t", $depth); // don't output children opening tag (`<ul>`)
				}
				function end_lvl(&$output, $depth){
				  $indent = str_repeat("\t", $depth); // don't output children closing tag
				}
				function start_el(&$output, $item, $depth, $args){
				  // add spacing to the title based on the depth
				  $item->title = str_repeat("&nbsp;", $depth * 4).$item->title;
				  parent::start_el(&$output, $item, $depth, $args);
				  // no point redefining this method too, we just replace the li tag...
				  $output = str_replace('<li', '<option', $output);
				}
				function end_el(&$output, $item, $depth){
				  $output .= "</option>\n"; // replace closing </li> with the option tag
				}
			}

			wp_nav_menu(array(
			'theme_location' => 'top', // your theme location here
			'walker'         => new Walker_Nav_Menu_Dropdown(),
			'items_wrap'     => '<select id="%1$s">%3$s</select>',
			'menu'            => 'top', 
			'container'       => 'select', 
			'container_class' => 'sf-menu', 
			'container_id'    => 'comboNav',
			'menu_class'      => 'sf-menu', 
			'menu_id'         => 'comboNav',
			'echo'            => true,
			'fallback_cb'     => 'wp_page_menu',
			'depth'           => 0
			)); ?>

				
			
			<!-- slider holder -->
			<div class="clearfix"></div>
			<?php
				if (is_front_page() ) { // Подключаю слайдер если главная
				require_once( trailingslashit( get_template_directory() ). 'slider.php' ); // действие для главной страницы
				} else {
				echo(''); // действие для не главной страницы
				}
			?>				
			<!-- slider holder -->
				
			</div>
		</header>