	<div id="slider-holder" class="clearfix">
		
		<!-- slider -->
		<div class="flexslider home-slider">
		  <ul class="slides">
	<li>
	  <img src="<?php echo get_template_directory_uri(); ?>/img/slides/01.jpg" alt="alt text" />
	</li>
	<li>
	  <img src="<?php echo get_template_directory_uri(); ?>/img/slides/02.jpg" alt="alt text" />
	  <p class="flex-caption">Pellentesque habitant morbi  feugiat vitae.</p>
	</li>
	<li>
	  <img src="<?php echo get_template_directory_uri(); ?>/img/slides/03.jpg" alt="alt text" />
	</li>
		  </ul>
		</div>
		<!-- ENDS slider -->
		
		<div class="home-slider-clearfix "></div>
		
		<!-- Headline -->
		<div id="headline">
		<h4>HELLO, I AM FREE</h4>
		<p class="headline-text">Simpler template is a totally FREE template for personal and commercial projects.</p> 
		<p class="headline-text">If you are looking for a WordPress version try the  <a href="http://themeforest.net/item/simpler-wordpress-theme/1630783?ref=Ansimuz" class="read-more" >Premium Version</a></p>
		
		</div>
		<!-- ENDS headline -->
		
	</div>
	<!-- ENDS slider holder -->