<?php get_header(); ?>

<!-- MAIN -->
<div id="main">
  <div class="wrapper clearfix"> 
    
    <!-- masthead -->
    <div class="masthead clearfix">
      <h1>
        <?php _e( 'Page not found', 'html5blank' ); ?>
      </h1>
    </div>
    <div class='mh-div'></div>
    <!-- ENDS masthead --> 
    
    <!-- Section -->
    <section> 
      
      <!-- page content -->
      <div id="page-content" class="clearfix">
        <h2><a href="<?php echo home_url(); ?>">
          <?php _e( 'Return home?', 'html5blank' ); ?>
          </a></h2>
      </div>
      <!-- ENDS page content --> 
      
    </section>
    <!-- /Section --> 
    
    <!-- Fold image -->
    <div id="fold"></div>
  </div>
</div>
<!-- ENDS MAIN -->
<?php get_footer(); ?>
