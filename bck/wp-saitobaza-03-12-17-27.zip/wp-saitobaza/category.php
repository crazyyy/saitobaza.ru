<?php get_header(); ?>

<!-- MAIN -->
<div id="main">
  <div class="wrapper clearfix"> 
    
    <!-- masthead -->
    <div class="masthead clearfix">
      <h1>
        <?php _e( '', 'html5blank' ); the_category(); ?>
      </h1>
      <span class="subheading">This is a subheading</span> </div>
    <div class='mh-div'></div>
    <!-- ENDS masthead --> 
    
    <!-- posts list -->
    <div id="posts-list" class="clearfix">
      <?php get_template_part('loop'); ?>
      
      <!-- Pagination -->
      <div id="pagination">
        <?php html5wp_pagination(); ?>
      </div>
      <!-- /Pagination --> 
      
    </div>
    <!-- ENDS posts list --> 
    
    <!-- sidebar -->
    <?php get_sidebar( '5' ); ?>
    
    <!-- Fold image -->
    <div id="fold"></div>
  </div>
</div>
<!-- ENDS MAIN -->

<?php get_footer(); ?>
