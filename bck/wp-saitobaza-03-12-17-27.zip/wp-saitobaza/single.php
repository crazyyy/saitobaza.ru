<?php get_header(); ?>		
		
		<!-- MAIN -->
		<div id="main">	
			<div class="wrapper clearfix">

				<!-- masthead -->
				<div class="masthead clearfix">
					<h1>ABOUT</h1><span class="subheading">In Photography, Recent work</span>
				</div>
				<div class='mh-div'></div>
				<!-- ENDS masthead -->
				
				
				<!-- posts list -->
	        	<div id="posts-list" class="single clearfix">     
						
					<?php if (have_posts()): while (have_posts()) : the_post(); ?>
	        	
					<article class="format-standard">
						<div class="entry-date"><div class="number"><?php the_time('j'); ?></div><div class="month"><?php the_time('M'); ?></div> <div class="year"><?php the_time('Y'); ?></div><em></em></div>
						<div  class="post-heading">
							<h4><?php the_title(); ?></h4>
							<div class="meta">
								<span class="user"><?php the_author_posts_link(); ?></span>
								<span class="comments"><?php comments_popup_link( __( 'комментировать', 'html5blank' ), __( 'комментарий', 'html5blank' ), __( '% коментариев', 'html5blank' )); ?></span>
							</div>
						</div>

						<?php 	 if ( has_post_thumbnail()) {
							   $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'large');
							   echo '<div class="feature-image"><a href="' . $large_image_url[0] . '" title="' . the_title_attribute('echo=0') . '"  data-rel="prettyPhoto">';
							   the_post_thumbnail(array(490,240));
							   echo '</a></div>';
							 }
							 ?>
							 
						<div class="excerpt"><?php the_content(); // Dynamic Content ?>
						</div>
						<br class="clear">
						<?php edit_post_link(); ?>
						
						<?php comments_template(); ?>
	
					</article>
					
					<?php endwhile; ?>
	
					<?php else: ?>
					
						<!-- Article -->
						<article>
							
							<h1><?php _e( 'Sorry, nothing to display.', 'html5blank' ); ?></h1>
							
						</article>
						<!-- /Article -->
					
					<?php endif; ?>
					
					
				
        	</div>
        	<!-- ENDS posts list -->
        	
        	
        	<!-- sidebar -->
			<?php get_sidebar( '5' ); ?>

			<!-- Fold image -->
			<div id="fold"></div>
			</div>
			
		</div>
		<!-- ENDS MAIN -->
		
<?php get_footer(); ?>