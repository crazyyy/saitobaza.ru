<?php get_header(); ?>	
			
		<!-- MAIN -->
		<div id="main">	
			<div class="wrapper clearfix">
				
				<!-- masthead -->
				<div class="masthead clearfix">
					<h1>ABOUT</h1><span class="subheading">Typography</span>
				</div>
				<div class='mh-div'></div>
				<!-- ENDS masthead -->
				
		<!-- Section -->
		<section>
				
				<!-- page content -->
	        	<div id="page-content" class="clearfix">        	
	        	
					<?php if (have_posts()): while (have_posts()) : the_post(); ?>
					
						<!-- Article -->
						<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
						
							<h4><?php the_title(); ?></h4>
						
							<?php the_content(); ?>
							
							<?php comments_template( '', true ); // Remove if you don't want comments ?>
							
							<br class="clear">
							
							<?php edit_post_link(); ?>
							
						</article>
						<!-- /Article -->
						
					<?php endwhile; ?>
					
					<?php else: ?>
					
						<!-- Article -->
						<article>
							
							<h2><?php _e( 'Sorry, nothing to display.', 'html5blank' ); ?></h2>
							
						</article>
						<!-- /Article -->
					
					<?php endif; ?>
				
        		</div>
        		<!-- ENDS page content -->
				
		</section>
		<!-- /Section -->
        	
        	

			<!-- Fold image -->
			<div id="fold"></div>
			</div>
			
		</div>
		<!-- ENDS MAIN -->
<?php get_footer(); ?>