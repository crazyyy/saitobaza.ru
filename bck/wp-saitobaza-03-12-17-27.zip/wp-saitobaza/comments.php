<?php if (have_comments()) : ?>

	<div id="comments-wrap">
		<h4 class="heading"><?php comments_number(); ?></h4>

	<ol class="commentlist">
		<?php wp_list_comments('type=comment&callback=html5blankcomments'); // Custom callback in functions.php ?>
	</ol>
	
	

<?php elseif ( ! comments_open() && ! is_page() && post_type_supports( get_post_type(), 'comments' ) ) : ?>
	
	<p><?php _e( 'Comments are closed here.', 'html5blank' ); ?></p>
	
<?php endif; ?>



<!-- Respond -->				
	<div id="respond">
		
		<?php $comments_args = array(
        // change the title of send button 
        'title_reply'=>'<h4>Прокомментировать</h4>',
		'cancel_reply_link' => __( 'отменить ответ' ),
        // remove "Text or HTML to be displayed after the set of comment fields"
        'comment_notes_after' => '',
		
		'comment_field' => '<p class="comment-form-comment"><label for="comment">' . _x( '', 'noun' ) . '</label><textarea id="comment" name="comment"  aria-required="true"></textarea></p>',
	'must_log_in' => '<p class="must-log-in">' .  sprintf( __( 'You must be <a href="%s">logged in</a> to post a comment.' ), wp_login_url( apply_filters( 'the_permalink', get_permalink( ) ) ) ) . '</p>',
	'logged_in_as' => '<p class="logged-in-as">' . sprintf( __( 'Logged in as <a href="%1$s">%2$s</a>. <a href="%3$s" title="Log out of this account">Log out?</a>' ), admin_url( 'profile.php' ), $user_identity, wp_logout_url( apply_filters( 'the_permalink', get_permalink( ) ) ) ) . '</p>',
		
		'fields' => apply_filters( 'comment_form_default_fields', array(
		'author' => '<p class="comment-form-author"><input id="author" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '" "' . $aria_req . ' />' . '<label for="author">' . __( 'Имя', 'domainreference' ) . '</label> ' . ( $req ? '<span class="required">*</span>' : '' ) . '</p>',
		'email' => '<p class="comment-form-email"><input id="email" name="email" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) . '" ' . $aria_req . ' /><label for="email">' . __( 'Email', 'domainreference' ) . '</label> ' . ( $req ? '<span class="required">*</span>' : '' ) . '</p>',
		'url' => '<p class="comment-form-url"><input id="url" name="url" type="text" value="' . esc_attr( $commenter['comment_author_url'] ) . '"  /><label for="url">' . __( 'Сайт', 'domainreference' ) . '</label>' . '</p>' ) ) );

comment_form($comments_args); ?>
		
		
	</div>
<div class="clearfix"></div>
<!-- ENDS Respond -->

