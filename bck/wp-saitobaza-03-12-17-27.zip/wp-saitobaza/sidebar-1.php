<!-- Sidebar -->
<aside id="footsidebar">


	<?php if ( is_active_sidebar( 'widget-area-1' ) ) : ?>
 
		<?php dynamic_sidebar( 'widget-area-1' ); ?>
 
	<?php else : ?>
 
						<div class="widget-block">
							<h4>ПОСЛЕДНИЕ ЗАПИСИ</h4>
							
								<?php
					$categories = get_the_category('1');
					$category_ids = array();
					foreach($categories as $individual_category) $category_ids[] = $individual_category->term_id;
					$args=array(
					'category__in' => $category_ids,
					'post__not_in' => array($post->ID),
					'showposts'=>3,
					'orderby'=>rand,
					'caller_get_posts'=>1);
					$my_query = new wp_query($args);
					if( $my_query->have_posts() ) {
					echo '';
					while ($my_query->have_posts()) {
					$my_query->the_post();
				?>

			
						<div class="recent-post clearfix">
								<?php 	 if ( has_post_thumbnail()) {
			   $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'large');
			   echo '<a class="widget54" href="' . $large_image_url[0] . '" title="' . the_title_attribute('echo=0') . '" >';
			   the_post_thumbnail(array(54,54));
			   echo '</a>';
			 }	?>
								<div class="post-head">
									<a href="<?php the_permalink() ?>" rel="nofollow" title="<?php the_title(); ?>"><?php the_title(); ?></a><span><?php the_time(__('j F, Y', 'kubrick')) ?></span>
								</div>
							</div>
			
			
				<?php	}
					echo '';	}
					wp_reset_query();	
				?>
						
						</div>
 
	<?php endif; ?>
		
</aside>
<!-- /Sidebar -->