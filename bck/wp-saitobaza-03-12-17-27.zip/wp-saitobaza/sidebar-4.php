<!-- Sidebar -->
<aside id="footsidebar">


	<?php if ( is_active_sidebar( 'widget-area-4' ) ) : ?>
 
		<?php dynamic_sidebar( 'widget-area-4' ); ?>
 
	<?php else : ?>
 
						<div class="widget-block">
							<h4>FREE TEMPLATES &amp; THEMES</h4>
							<p>Visit <a href="http://templatecreme.com/" >Template Creme</a> and browse the selection of well-made FREE Templates and WordPress Themes.</p>
						</div>
 
	<?php endif; ?>
		
</aside>
<!-- /Sidebar -->