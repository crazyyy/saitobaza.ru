<!-- Sidebar -->
<aside id="footsidebar">


	<?php if ( is_active_sidebar( 'widget-area-3' ) ) : ?>
 
		<?php dynamic_sidebar( 'widget-area-3' ); ?>
 
	<?php else : ?>
 
						<div class="widget-block">
							<div id="tweets" class="footer-col tweet">
		         				<h4>ЗАПИСИ С ТВИ</h4>
		         			</div>
		         		</div>
 
	<?php endif; ?>
		
</aside>
<!-- /Sidebar -->