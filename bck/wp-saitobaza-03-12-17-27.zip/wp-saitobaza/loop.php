	    <?php if (have_posts()): while (have_posts()) : the_post(); ?>
		
			<article class="format-standard">
			
		<div class="entry-date"><div class="number"><?php the_time('j'); ?></div><div class="month"><?php the_time('M'); ?></div> <div class="year"><?php the_time('Y'); ?></div><em></em></div>
		<div  class="post-heading">
			<h4><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h4>
			<div class="meta">
				<span class="user"><?php the_author_posts_link(); ?></span>
				<span class="comments"><?php comments_popup_link( __( 'комментировать', 'html5blank' ), __( 'комментарий', 'html5blank' ), __( '% коментариев', 'html5blank' )); ?></span>
			</div>
		</div>
			<?php 	 if ( has_post_thumbnail()) {
			   $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'large');
			   echo '<div class="feature-image"><a href="' . $large_image_url[0] . '" title="' . the_title_attribute('echo=0') . '"  data-rel="prettyPhoto">';
			   the_post_thumbnail(array(490,240));
			   echo '</a></div>';
			 }	?>
		<div class="excerpt"><?php html5wp_excerpt('html5wp_index'); // Build your custom callback length in functions.php ?>
		</div>
		
			</article>
			

		<?php endwhile; ?>

		<?php else: ?>

			<!-- Article -->
			<article>
			<div class="404page">
				<h1>Страница 404й ошибки</h1>
				<br />
				<h2><?php _e( 'и показать вам нечего;(', 'html5blank' ); ?></h2>
			</div>
				
			</article>
			<!-- /Article -->

		<?php endif; ?>	