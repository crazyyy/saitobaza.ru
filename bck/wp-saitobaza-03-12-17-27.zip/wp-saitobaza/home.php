<?php get_header(); ?>
		
		<!-- MAIN -->
		<div id="main">	
			<div class="wrapper clearfix">
				
				
        		<!-- home-block -->
	        	<div class="home-block clearfix" >
	        		<h1 class="home-headline">МОИ УСЛУГИ </h1>
	        		
	        		<!-- thumbs -->
	        		<div class="clearfix" >
	        			
	        			<figure>
			        		<a href="single.html"  class="thumb"><img src="<?php echo get_template_directory_uri(); ?>/img/dummies/featured-1.jpg" alt="Alt text" /></a>
			        		<figcaption>
	        					<strong>Pellentesque habitant morbi</strong>
	        					<span>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae.</span>
			        		</figcaption>
		        		</figure>
		        		
		        		<figure>
			        		<a href="single.html"  class="thumb"><img src="<?php echo get_template_directory_uri(); ?>/img/dummies/featured-2.jpg" alt="Alt text" /></a>
			        		<figcaption>
	        					<strong>Pellentesque habitant morbi</strong>
	        					<span>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae.</span>
			        		</figcaption>
		        		</figure>
		        		
		        		<figure>
			        		<a href="single.html"  class="thumb"><img src="<?php echo get_template_directory_uri(); ?>/img/dummies/featured-3.jpg" alt="Alt text" /></a>
			        		<figcaption>
	        					<strong>Pellentesque habitant morbi</strong>
	        					<span>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae.</span>
			        		</figcaption>
		        		</figure>
		        		
		        		<figure>
			        		<a href="single.html"  class="thumb"><img src="<?php echo get_template_directory_uri(); ?>/img/dummies/featured-1.jpg" alt="Alt text" /></a>
			        		<figcaption>
	        					<strong>Pellentesque habitant morbi</strong>
	        					<span>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae.</span>
			        		</figcaption>
		        		</figure>
		        		
		        		<figure>
			        		<a href="single.html"  class="thumb"><img src="<?php echo get_template_directory_uri(); ?>/img/dummies/featured-3.jpg" alt="Alt text" /></a>
			        		<figcaption>
	        					<strong>Pellentesque habitant morbi</strong>
	        					<span>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae.</span>
			        		</figcaption>
		        		</figure>
		        		
		        		<figure>
			        		<a href="single.html"  class="thumb"><img src="<?php echo get_template_directory_uri(); ?>/img/dummies/featured-2.jpg" alt="Alt text" /></a>
			        		<figcaption>
	        					<strong>Pellentesque habitant morbi</strong>
	        					<span>Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae.</span>
			        		</figcaption>
		        		</figure>
		        		
	        		</div>
	        		<!-- ENDS thumbs -->
	        		
	        		<a href="work.html" class="theme-link-button">See All Work</a>
	        		
	        	</div>
	        	<!-- ENDS home-block -->
	        	
	        	
	        	<!-- additional blocks -->
	        	<div class="home-add clearfix">
	        		
	        		<!-- left -->
	        		<div class="left-home-block home-posts">
	        			<h4 class="heading">FROM THE BLOG</h4>
	
				<?php
					$categories = get_the_category('1');
					$category_ids = array();
					foreach($categories as $individual_category) $category_ids[] = $individual_category->term_id;
					$args=array(
					'category__in' => $category_ids,
					'post__not_in' => array($post->ID),
					'showposts'=>5,
					'orderby'=>rand,
					'caller_get_posts'=>1);
					$my_query = new wp_query($args);
					if( $my_query->have_posts() ) {
					echo '';
					while ($my_query->have_posts()) {
					$my_query->the_post();
				?>

					<article class="format-standard">
					<div class="entry-date"><div class="number"><?php the_time(__('j', 'kubrick')) ?></div><div class="month"><?php the_time(__('M', 'kubrick')) ?></div> <div class="year"><?php the_time(__('Y', 'kubrick')) ?></div><em></em></div>
					<div  class="post-heading">
						<h4><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a></h4>
					</div>
					<div class="excerpt"><?php the_excerpt_max_charlength(100); ?></div>
					</article>
			
				<?php	}
					echo '';	}
					wp_reset_query();	
				?>
						
						
						
	        		</div>
	        		<!-- ENDS left -->
	        		
	        		<!-- right -->
	        		<div class="right-home-block">
	        			
	        			
	        			<h4 class="heading">CLIENTS</h4>
	        			
	        			<!-- logos -->
	        			<ul class="clients-logos clearfix">
	        				<li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/dummies/logo1.png" alt="logo" /></a></li>
	        				<li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/dummies/logo2.png" alt="logo" /></a></li>
	        				<li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/dummies/logo3.png" alt="logo" /></a></li>
	        				<li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/dummies/logo4.png" alt="logo" /></a></li>
	        				<li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/dummies/logo5.png" alt="logo" /></a></li>
	        				<li><a href="#"><img src="<?php echo get_template_directory_uri(); ?>/img/dummies/logo6.png" alt="logo" /></a></li>
	        			</ul>
	        			<!-- ENDS logos -->
	        			
	        			
	        			<h4 class="heading">TESTIMONIALS</h4>
	        			
	        			<!-- testimonial slider -->
				        <div class="flexslider testimonial-slider">
						  <ul class="slides">
						    <li>
						      Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Vestibulum tortor quam, feugiat vitae, ultricies eget.
						      <div class="client-name">- Luis Zuno, Webdesigner</div>
						    </li>
							<li>
						      at vitae, ultricies eget, tempor sit amet, ante. Donec 
						      <div class="client-name">- Luis Zuno, Webdesigner</div>
						    </li>
						    
						   <li>
						     Quisque sit amet est et sapien ullamcorper pharetra. Vestibulum erat wisi, condimentum sed, commodo vitae, ornare sit amet, wisi.
						     <div class="client-name">- Luis Zuno, Webdesigner</div>
						    </li>
						  </ul>
						  
						</div>
			        	<!-- ENDS testimonial slider -->
		        	
		        		
	        		</div>
	        		<!-- ENDS right -->
	        		
	        	</div>
        		<!-- ENDS additional blocks -->

			<!-- Fold image -->
			<div id="fold"></div>
			</div>
			
		</div>
		<!-- ENDS MAIN -->
		
<?php get_footer(); ?>