		
		<footer>	
			
			<div class="wrapper clearfix">
				
				<!-- widgets -->
				<ul  class="widget-cols clearfix">
					<li class="first-col">
						<?php get_sidebar( '1' ); ?>
					</li>
					
					<li class="second-col">
						<?php get_sidebar( '2' ); ?>
					</li>
					
					<li class="third-col">
						<?php get_sidebar( '3' ); ?>
					</li>
					
					<li class="fourth-col">
						<?php get_sidebar( '4' ); ?>	
					</li>	
				</ul>
				<!-- ENDS widgets -->	
				
				
				<!-- bottom -->
				<div class="footer-bottom">
					<div class="left">Шаблон создан мной специально для <a href="http://saitobaza.ru" >Сайтобазы</a></div>
					<div class="right">
						<ul id="social-bar">
							<li><a rel="nofollow" href="http://www.facebook.com"  title="Друзяшка в FB" class="poshytip"><img src="<?php echo get_template_directory_uri(); ?>/img/social/facebook.png"  alt="Facebook" /></a></li>
							<li><a rel="nofollow" href="https://twitter.com/saitobaza" title="Следить в твиттере" class="poshytip"><img src="<?php echo get_template_directory_uri(); ?>/img/social/twitter.png"  alt="twitter" /></a></li>
							<li><a rel="nofollow"  href="http://www.google.com"  title="Добавить в круг Google+" class="poshytip"><img src="<?php echo get_template_directory_uri(); ?>/img/social/plus.png" alt="Google plus" /></a></li>
						</ul>
					</div>
				</div>	
				<!-- ENDS bottom -->		

			</div>
		</footer>
		
		<?php wp_footer(); ?>	
	</body>
	
</html>