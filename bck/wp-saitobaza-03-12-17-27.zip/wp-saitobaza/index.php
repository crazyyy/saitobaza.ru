<?php get_header(); ?>
		
		
		<!-- MAIN -->
		<div id="main">	
			<div class="wrapper clearfix">
				
				<!-- masthead -->
				<div class="masthead clearfix">
					<h1>BLOG</h1><span class="subheading">This is a subheading</span>
				</div>
				<div class='mh-div'></div>
				<!-- ENDS masthead -->
			
				
				
				<!-- posts list -->
	        	<div id="posts-list" class="clearfix">        

				<?php get_template_part('loop'); ?>
				
				
				
				<!-- page-navigation -->
				<div class="page-navigation clearfix">
					<div class="nav-next"><?php next_posts_link(__('&laquo; старые', 'kubrick')) ?></div>
					<div class="nav-previous"><?php previous_posts_link(__('новые &raquo;', 'kubrick')) ?></div>
				</div>
				<!--ENDS page-navigation -->
				
				</div>
        		<!-- ENDS posts list -->
        	
        	
        	<!-- sidebar -->
			<?php get_sidebar( '5' ); ?>

			<!-- Fold image -->
			<div id="fold"></div>
			</div>
			
		</div>
		<!-- ENDS MAIN -->
		
		
<?php get_footer(); ?>