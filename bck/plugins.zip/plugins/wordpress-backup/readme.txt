=== Wordpress Backup ===
Contributors: Blog Traffic Exchange (http://www.blogtrafficexchange.com)
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=2282479
Tags: admin, backup, images, uploads, theme, plugin, bte
Requires at least: 2.5
Tested up to: 3.2
Stable tag: 1.8.2

Backup the upload directory (images), current theme directory, and plugins directory to a zip file.  Zip files optionally sent to email.

== Description ==

Backup the upload directory (images), current theme directory, and plugins directory to a zip file.  Zip files optionally sent to email.

[Wordpress Backup](http://www.blogtrafficexchange.com/wordpress-backup "Wordpress Backup") by [Blog Traffic Exchange](http://www.blogtrafficexchange.com/ "Blog Traffic Exchange")

Check out my other [Wordpress Plugins](http://www.blogtrafficexchange.com/wordpress-plugins "Wordpress Plugins")

== Installation ==

1. Upload wordpress-backup to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Optionally adjust the options

== Screenshots ==

1. [Wordpress Backup](http://www.blogtrafficexchange.com/wordpress-backup "Wordpress Backup") Options

== Frequently Asked Questions ==

= Emails are not being sent?  =

Please note that as the size of the zip files increase, it may not be possible to email the files due to limitations of email servers.  Be sure that your memory limits are set high enough in your php.ini

= What is the plugin page?  =

[Wordpress Backup](http://www.blogtrafficexchange.com/wordpress-backup "Wordpress Backup") by [Blog Traffic Exchange](http://www.blogtrafficexchange.com/ "Blog Traffic Exchange")

= Do you have other plugins?  =

[Related Websites](http://www.blogtrafficexchange.com/related-websites "Related Websites")
[Related Tweets](http://www.blogtrafficexchange.com/related-tweets "Related Tweets")
[Blog Post Promoter](http://www.blogtrafficexchange.com/old-post-promoter "Blog Post Promoter")
[Wordpress Backup](http://www.blogtrafficexchange.com/wordpress-backup "Wordpress Backup")
[Blog Copyright](http://www.blogtrafficexchange.com/blogcopyright "Blog Copyright")
[Related Posts](http://www.blogtrafficexchange.com/related-posts "Related Posts")
[Online Stores](http://www.blogtrafficexchange.com/online-stores "Online Stores")
[Click to Call](http://www.blogtrafficexchange.com/click-to-call "Click to Call")

I am working on several others, when released you will find them on my [Wordpress Plugins](http://www.blogtrafficexchange.com/wordpress-plugins "Wordpress Plugins") page.
