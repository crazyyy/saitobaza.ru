<?php $abspath = '/var/www/crazyyy/data/www/saitobaza.ru/'; ?>
